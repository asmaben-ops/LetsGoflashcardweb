
let cards = [
  {english: "Hello", arabic: "مرحبا"},
  {english: "Goodbye", arabic: "وداعا"},
  {english: "Thank you", arabic: "شكرا"}
];

let currentIndex = 0;
const cardEl = document.getElementById("card");
const frontEl = document.getElementById("card-front");
const backEl = document.getElementById("card-back");
const progressEl = document.getElementById("progress");

function updateCard() {
  frontEl.textContent = cards[currentIndex].english;
  backEl.textContent = cards[currentIndex].arabic;
  progressEl.textContent = `Card ${currentIndex + 1} / ${cards.length}`;
  cardEl.classList.remove("flipped");
}

function flipCard() {
  cardEl.classList.toggle("flipped");
}

function nextCard() {
  currentIndex = (currentIndex + 1) % cards.length;
  updateCard();
}

function addCard() {
  const front = document.getElementById("front-input").value;
  const back = document.getElementById("back-input").value;
  if(front && back) {
    cards.push({english: front, arabic: back});
    document.getElementById("front-input").value = "";
    document.getElementById("back-input").value = "";
    alert("Card added!");
    updateCard();
  } else {
    alert("Please enter both English and Arabic.");
  }
}

// Initialize card
updateCard();
